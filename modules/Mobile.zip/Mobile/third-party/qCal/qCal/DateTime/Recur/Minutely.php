<?php
class qCal_DateTime_Recur_Minutely extends qCal_DateTime_Recur {

	protected function doGetRecurrences($rules, $start, $end) {
	
		// do stuff!
	
	}

}